import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './UserStats.css';  // Import the CSS file
import MatchHistory from './MatchHistory';
import LiveMatch from './LiveMatch';

const UserStats = ({ riotId }) => {
  const [userStats, setUserStats] = useState(null);
  const [matchHistory, setMatchHistory] = useState(null);
  const [liveMatch, setLiveMatch] = useState(null);
  const [error, setError] = useState(null);
  const [liveMatchError, setLiveMatchError] = useState(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [gameName, tagLine] = riotId.split('#');
  
        // GraphQL query that combines user stats, match history, and live match data
        const graphqlQuery = `
          query getAllData($gameName: String!, $tagLine: String!) {
            userStats(gameName: $gameName, tagLine: $tagLine) {
              field1
              field2
              // Add other fields you need
            }
            matchHistory(gameName: $gameName, tagLine: $tagLine) {
              field1
              field2
              // Add other fields you need
            }
            liveMatch(gameName: $gameName, tagLine: $tagLine) {
              field1
              field2
              // Add other fields you need
            }
          }
        `;
  
        // Make a single API call to the GraphQL endpoint
        const response = await axios.post('http://localhost:3001/graphql', {
          query: graphqlQuery,
          variables: { gameName, tagLine }
        });
  
        // Extract data from the GraphQL response
        const { userStats, matchHistory, liveMatch } = response.data.data;
  
        // Update the state with the fetched data
        setUserStats(userStats);
        setMatchHistory(matchHistory);
        setLiveMatch(liveMatch);
        
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Failed to fetch data');
      }
    };
  
    fetchStats();
  }, [riotId]);

  if (error) return <div>{error}</div>;
  if (!userStats || !matchHistory) return <div>Loading...</div>;

  const profileIconUrl = `https://ddragon.leagueoflegends.com/cdn/14.14.1/img/profileicon/${userStats.profileIconId}.png`;

  return (
    <div className="user-stats">
      <h2>User Stats</h2>
      <img src={profileIconUrl} alt="Profile Icon" style={{ width: '50px', height: '50px' }} />
      <p>Name: {userStats.name}</p>
      <p>Summoner Level: {userStats.summonerLevel}</p>
      <p>Game Name and Tagline: {riotId}</p>
      <MatchHistory matchHistory={matchHistory} />
      <LiveMatch liveMatch={liveMatch} liveMatchError={liveMatchError} />
    </div>
  );
};

export default UserStats;
